package vuong.cs146.project3;

public enum MazePathEnum {
    PATH(1),
    PATHDFS(2),
    PATHBFS(3);
	
	private int value;
	MazePathEnum(int val) {
		this.value = val;
	}
	public int getValue() {
		return this.value;
	}
}