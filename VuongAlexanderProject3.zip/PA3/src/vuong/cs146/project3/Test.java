package vuong.cs146.project3;

public class Test {

	public static void main(String[] args) {
        int mazeSize = 4;
        Maze maze = new Maze(mazeSize);
        maze.init(); 
        maze.mazeGenerator();
        maze.displayMaze(MazePathEnum.PATH);  
	}
}