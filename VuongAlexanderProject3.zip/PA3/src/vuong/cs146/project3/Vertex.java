package vuong.cs146.project3;

import java.util.ArrayList;

public class Vertex {
	int x;
	int y;

	//private List<Vertex> edgesList;
	ArrayList<Vertex> allEdges = new ArrayList<Vertex>();
	public int label;
	
	public boolean hasSouthWall = true;
	public boolean hasNorthWall = true;
	public boolean hasEastWall = true;
	public boolean hasWestWall = true;
	
	boolean isVisited = false;
	boolean isInPath = false;
	
	int visitBfsOrder;
	int visitedOrder = 0;
	
	int dtime;
	
	Vertex parent;
	
	public Vertex(int x, int y){
		this.x = x;
		this.y = y;
	}

	public boolean isVisited() {
		// TODO Auto-generated method stub
		return true;
	}
}
