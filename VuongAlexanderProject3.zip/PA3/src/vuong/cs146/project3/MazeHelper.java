package vuong.cs146.project3;

import java.util.Iterator;

public class MazeHelper {
	public static int allValidEdges(Vertex v){
        Iterator<Vertex> it = v.allEdges.iterator(); //traverses through nodes
        while (it.hasNext()){
            Vertex v1 = it.next();
            if(v1.isVisited){ //if vertex has been visited already
                it.remove(); //remove edges
            }
        }
        int neighbors =0;
        for(int x = 0; x < v.allEdges.size(); x++){ //goes through loop to check if edges have been visited and increments edges visited
            if(!v.allEdges.get(x).isVisited){
                neighbors++;
            }
        }
        return neighbors ;
    }
	
	public static void removesWall(Vertex current, Vertex next, int size) { //removes wall at current Node
        if(current.label + size == next.label)
        {
            //remove south wall
            current.hasSouthWall = false;
            next.hasNorthWall = false;
        }
        else if(current.label + 1 == next.label)
        {
            //remove east wall
            current.hasEastWall = false;
            next.hasWestWall = false;
        }
        else if(current.label -1 == next.label)
        {
            //remove the west wall
            current.hasWestWall = false;
            next.hasEastWall = false;
        }
        else if(current.label - size == next.label)
        {
            //remove the northern wall
            current.hasNorthWall = false;
            next.hasSouthWall = false;
        }

        current.allEdges.remove(next);
        next.allEdges.remove(current);
    }
}

