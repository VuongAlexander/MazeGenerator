package vuong.cs146.project3;

import java.util.Random;
import java.util.Stack;

public class Maze{
	int SIZE; //Size of Maze
	int totalCells; //Size * Size for row and column
	int[][] adjMatrix; //Adjacent Matrix is used for graph in integer form. uses 1 and 0
	Stack<Vertex> cellStack; //Goes through the maze and recursively backtracks
	int visitedCells; //updates with cellStack
	Vertex[][] graph; //
	Vertex currentCell; //
	Node[] adjList; //
    
    public Maze(int size)
    {
        this.SIZE = size;
        totalCells = SIZE * SIZE; // row * column
        adjMatrix = new int[SIZE][SIZE];
        for(int i = 0; i < SIZE; i++){
            for(int j = 0; j < SIZE; j++){
                adjMatrix[i][j] = 0;
             // Fills Maze of Size with 0
				 /* Example
				  * { 0 0 0 0
				  *   0 0 0 0
				  *   0 0 0 0
				  *   0 0 0 0 }
				  */
            }
        }
        adjList = new Node[totalCells];
        for(int i = 0; i < totalCells; i++){
            adjList[i] = null;
        }
        cellStack = new Stack<Vertex>();
        graph = new Vertex[SIZE][SIZE];
    }
    
    public void init()
    {
        int vertexNumber = 1;
        //This loop creates a new vertex
        for(int i=0; i < SIZE; i++){
            for(int j = 0; j < SIZE; j++)
            {
                Vertex v = new Vertex(j,i);
                graph[j][i] = v;
            }
        }
        //adds values to vertex
        for(int i = 0; i < SIZE; i++){
            for(int j = 0; j < SIZE; j++){
                graph[j][i].label = vertexNumber;
                graph[j][i].parent = null;
                vertexNumber++;
            }
        }
        //This loop assigns the neighbors
        for(int i = 0; i < SIZE; i++){
            for(int j = 0; j < SIZE; j++){
                assignNeighbors(graph[j][i]);
            }
        }
    }
    
    public void assignNeighbors(Vertex v)
    {
        //cell north of current cell
        if(v.y != 0)
        {
            v.allEdges.add(graph[v.x][v.y-1]);
        }

        //cell south of the current cell
        if(v.y != (SIZE-1))
        {
            v.allEdges.add(graph[v.x][v.y+1]);
        }

        //cell west of the current cell
        if(v.x != 0)
        {
            v.allEdges.add(graph[v.x -1][v.y]);
        }

        //east of the current
        if(v.x != SIZE-1)
        {
            v.allEdges.add(graph[v.x + 1][v.y]);
        }
    }
    
    public void mazeGenerator() { //uses DFS
        currentCell = graph[0][0]; //starts at 0,0 of graph
        currentCell.isVisited = true;
        visitedCells = 1;

        while(visitedCells < totalCells){
        	int validNeighborsNum = MazeHelper.allValidEdges(currentCell); //finds all cells with walls intact
            if(validNeighborsNum != 0){ //if one or more found, choose one at random to remove
                Vertex vtx = null;

                Random generator = new Random();
                int random = generator.nextInt(validNeighborsNum);
                vtx = currentCell.allEdges.get(random);

                MazeHelper.removesWall(currentCell, vtx, SIZE); //knock down the wall between it(v) and currentCell

                Node newNode = new Node(vtx);
                Node currentNode = adjList[currentCell.label-1];
                if (currentNode == null) { //if the current node does not exist
                    currentNode = newNode;
                    adjList[currentCell.label-1] = currentNode;
                }
                else {
                    while(currentNode.next != null){
                        currentNode = currentNode.next;
                    }
                    currentNode.next = newNode;
                }

                Node newNode2 = new Node(currentCell);
                currentNode = adjList[vtx.label-1];
                if (currentNode == null) {
                    currentNode = newNode2;
                    adjList[vtx.label-1] = newNode2;
                }
                else {
                    while(currentNode.next != null){
                        currentNode = currentNode.next;
                    }
                    currentNode.next = newNode2;
                }
                cellStack.push(currentCell); //push currentCell location onto cellStack
                currentCell = vtx; //make new cell CurrentCell
                currentCell.isVisited = true; //checks if visited
                visitedCells++; //add 1 to visitedCells
            }else{
            	if(!cellStack.isEmpty()){ //if cellStack is empty
	         		Vertex v = cellStack.pop(); //pop the most recent cell entry off cellStack
	         		currentCell = v; //make it(v) currentCell
                }
            }
        }
    }
    
    public void displayMaze(MazePathEnum path){
        System.out.println("");
        for(int i = 0; i < SIZE; i++){
            for(int j =0; j < SIZE; j++){
                if(graph[j][i].hasNorthWall){
                    if(graph[j][i] == graph[0][0]) 
                        System.out.print("+   ");
                    else
                        System.out.print("+---");
                }
                else{// open wall
                    System.out.print("+   ");
                }
            }// end inner loop
            System.out.println("+");
            for(int j =0; j < SIZE; j++){
                // PATH = display path with #s
                if(path == MazePathEnum.PATH){
                    if(graph[j][i].hasWestWall){
                        if(graph[j][i].isInPath)
                            System.out.print("| " + "#"+" ");
                        else
                            System.out.print("|   ");
                    }
                    else{
                        if(graph[j][i].isInPath)
                            System.out.print(" " + "#" +" ");
                        else
                            System.out.print("    ");
                    }
                }
                // PATHBFS 
                else if(path == MazePathEnum.PATHBFS){
                    if(graph[j][i].hasWestWall){
                        //graph[j][i].distance <= graph[SIZE-1][SIZE-1].distance
                        if(graph[j][i].visitBfsOrder <= graph[SIZE-1][SIZE-1].visitBfsOrder)
                        {
                            System.out.print("| " + String.format("%2s", graph[j][i].visitBfsOrder));
                        }
                        else
                            System.out.print("|   ");
                    }
                    else{
                        if(graph[j][i].visitBfsOrder <= graph[SIZE-1][SIZE-1].visitBfsOrder){
                            System.out.print(" " + String.format("%2s", graph[j][i].visitBfsOrder));
                        }
                        else
                            System.out.print("    ");
                    }
                }
                else if(path == MazePathEnum.PATHDFS){
                    if(graph[j][i].hasWestWall){
                        if(graph[j][i].dtime <= graph[SIZE-1][SIZE-1].dtime){
                            System.out.print("| " + String.format("%2s", graph[j][i].visitedOrder));
                        }
                        else
                            System.out.print("|   ");
                    }
                    else{
                        if(graph[j][i].dtime <= graph[SIZE-1][SIZE-1].dtime){
                            System.out.print(" " + String.format("%2s", graph[j][i].visitedOrder));
                        }
                        else
                            System.out.print("    ");
                    }
                }
            }// end inner loop
            System.out.println("|");
        }
        for(int j =0; j < SIZE; j++){
            if(j == SIZE-1)
                System.out.print("+   ");
            else
                System.out.print("+---");
        }// end inner loop
        System.out.println("+");
    }
}
