package vuong.cs146.project3;

public class Node {
	Node next = null;
	Vertex v;
	public Node(Vertex v) {
		this.v = v;
	}
}
